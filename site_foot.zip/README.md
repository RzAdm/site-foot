# Site de Biographies de Joueurs de Football
Ce projet est un site web simple présentant les biographies de célèbres joueurs de football.

## Contenu :
- **index.html** : Page principale avec des biographies de Messi, Ronaldo et Neymar.
- **page2.html** : Légendes du football (Pelé, Maradona, Zidane).
- **sous_dossier/page3.html** : Jeunes talents du football.

## Comment l'héberger sur GitHub Pages :
1. Crée un dépôt GitHub public.
2. Ajoute les fichiers de ce projet dans le dépôt.
3. Va dans **Settings > Pages** et active GitHub Pages sur la branche `main`.
4. Ton site sera accessible via `https://tonpseudo.github.io/nom_du_depot/`.

## Auteur :
Projet réalisé pour l'apprentissage du HTML.
